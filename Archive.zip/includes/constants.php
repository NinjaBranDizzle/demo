<?php
	//Define constants here
	define('DB_SERVER', 'localhost');
	define('DB_USER', 'spincent_admin');
	define('DB_PASSWORD', 'Justhost!984');
	define('DB_NAME','spincent_school');
?>