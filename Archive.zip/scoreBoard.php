<div class="scoreboard">
    <div class="bar clearfix">
    	<div class="imgContainer col ">
        	<img src="https://db.tt/gpeW8ipD" width="80px" class="p1image">
        </div>
        <div class="nameContainer col">
	        <p class="player">Rango</p>
	    </div>
	    <div class="scoreContainer col">
	    	<p class="score">210</p>
	    </div>
    </div>

    <div class="bar clearfix">
    	<div class="imgContainer col ">
        	<img src="https://db.tt/o5PYWFFQ" width="80px" class="p2image">
        </div>
        <div class="nameContainer col">
	        <p class="player">Rango</p>
	    </div>
	    <div class="scoreContainer col">
	    	<p class="score">210</p>
	    </div>
    </div>
</div>