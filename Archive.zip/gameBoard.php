<?php 
    //Create new unit object to get attributes
    $con = mysqli_connect('localhost', 'spincent_admin', 'Justhost!984', 'spincent_school'); 
    // Check connection
    if (mysqli_connect_errno($con))
      {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
      }

    // Perform queries 
    $units = mysqli_query($con,"SELECT * FROM BS_UNIT");
    mysqli_close($con);
?>

<div class="mapContainer">
    <?php 
        for($i=0; $i <= 215; $i++){
            while($row = mysqli_fetch_array($units, MYSQL_ASSOC))
            { ?>
            <div class="cell">
                <img src="<?php echo $row['UNIT_URL']; ?>" id="<?php echo $row['UNIT_ID']; ?>" class="redJetPopup unitPopup" />
                <div id="<?php echo $row['UNIT_ID']; ?>Content" class="unitStats">
                    <h4><?php echo $row['UNIT_DESC']; ?></h4>
                    <p>Health: <?php echo $row['HEALTH']; ?>/100</p>
                    <p>Super Power: <?php echo $row['HAS_SUPER_POWER']; ?>/1</p>
                </div>
            </div>
    <?php $i++;
            }
    ?>
    <div class="cell"></div>
    <?php 
        }
    ?>   
</div>

<div class="buttonContainer clearfix">
    <div class="mapSelect">
        <select id="map" class="form-control">
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
        </select>
        <button id="selectMap" class="btn btn-primary btn-sm">Select Map</button>
    </div>
    <div class="gridSelect">
        <button id="toggleGridOff" class="btn btn-danger btn-sm">Grid Off</button>
        <button id="toggleGridOn" class="btn btn-success btn-sm">Grid On</button>
    </div>
</div>